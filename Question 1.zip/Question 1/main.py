# This is a sample Python script.

import pandas as pd
import matplotlib.pyplot as plt
bakery_dataset = pd.read_csv("BreadBasket_DMS.csv")
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']
topten=bakery_dataset['Item'].value_counts().head(10)

print(topten)
topten.plot(kind='bar')
plt.show()